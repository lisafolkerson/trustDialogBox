$(function() {
	$( '.clickable' ).trustDialogBox();

}); // end doc ready